package es.ucm.abd.practica2.model;

/**
 *
 * @author manuel
 */
public enum Orientation {
    HORIZONTAL, VERTICAL    
}
